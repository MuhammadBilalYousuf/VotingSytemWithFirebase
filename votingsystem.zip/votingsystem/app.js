const express = require('express');
const bodyParser = require('body-parser');
const app = express()

app.set('view engine', 'ejs')
app.use(express.static('views'))
app.set('views', __dirname + '/views')
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: false}))

app.get('/', (req, res) => {
   res.render('home.ejs')
})

app.post('/', (req, res) => {
    const somedata = req.body.some
    res.render('results.ejs',{data: somedata})
})
const port = process.env.PORT || 3000

app.listen(port, () => {
    console.log("running " + port)
})